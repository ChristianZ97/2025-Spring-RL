from transformers import AutoProcessor,  TrainingArguments, Trainer,  Idefics3ForConditionalGeneration, TrainerCallback      
from datasets import load_from_disk
from PIL import Image
import torch
import os
import time
import re

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
print(os.environ["CUDA_VISIBLE_DEVICES"]) 

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model_id = "HuggingFaceTB/SmolVLM-256M-Instruct"
processor = AutoProcessor.from_pretrained(model_id, use_fast=True)

# train
################################################################################################################
model_path = r"D:\PH5\PH5\RL\checkpoints_rloo_only\stage1_model_reason"
model = Idefics3ForConditionalGeneration.from_pretrained(
    model_id,
    # model_path,
    torch_dtype=torch.bfloat16,
    low_cpu_mem_usage=True,
    device_map="auto",
    _attn_implementation="flash_attention_2" if device == "cuda" else "eager",
    use_cache=False
)

model.to(device)

dataset_train = load_from_disk(r"D:\PH5\PH5\RL\bdd_train_1act&1rsn_1407")
dataset_val = load_from_disk(r"D:\PH5\PH5\RL\bdd_train_1act&1rsn_200")

print("Train Dataset Features:", dataset_train) # .features
# print("Val Dataset Features:", dataset_val)

image_root = r"D:\PH5\lastframe"

image_token_id = processor.tokenizer.additional_special_tokens_ids[
            processor.tokenizer.additional_special_tokens.index("<image>")]
def collate_fn(examples):
    texts = []
    images = []

    model.eval()  # Set to eval mode for caption generation
    with torch.no_grad():
        for i in range(len(examples)):
            # 讀取圖片
            img_path = os.path.join(image_root, examples[i]["image"])
            img = Image.open(img_path)
            if img.mode != 'RGB':
                img = img.convert('RGB')

            # 第一階段：圖片 -> Caption
            messages = [
                # {
                #     "role": "system",
                #     "content": [{"type": "text", "text": system_message}],
                # },
                {
                    "role": "user",
                    "content": [
                        # {"type": "text", "text": "Answer briefly."},
                        {"type": "image"},
                        # {"type": "text", "text": question}
                    ]
                }
            ]            
            first_stage_inputs = processor.apply_chat_template(messages, add_generation_prompt=False)
            inputs = processor(text=first_stage_inputs, images=img, return_tensors="pt")
            inputs = inputs.to(device)
            generated_ids = model.generate(**inputs, max_new_tokens=64)
            caption = processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()

            # 第二階段：Caption + 圖片 + Prompt -> 預測動作
            prompt = "Based on the caption and image, what is the next action: <forward, stop, left, right>?"
            combined_input = f"Caption: {caption}\n{prompt}"

            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": combined_input},
                        {"type": "image"}
                    ]
                },
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": examples[i]["text"].split("Action:")[1].split('.')[0].strip()}
                    ]
                }
            ]

            text = processor.apply_chat_template(messages, add_generation_prompt=False)
            texts.append(text.strip())
            images.append(img)

    batch = processor(
        text=texts,
        images=images,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=2048
    )

    labels = batch["input_ids"].clone()
    labels[labels == processor.tokenizer.pad_token_id] = -100
    labels[labels == image_token_id] = -100
    batch["labels"] = labels
    return batch



# 設定訓練參數
model_name = model_id.split("/")[-1]
training_args = TrainingArguments(
    # dataloader_pin_memory = True,
    # dataloader_num_workers=4,
    include_num_input_tokens_seen=True,
    num_train_epochs=3,
    per_device_train_batch_size=4,
    gradient_accumulation_steps=4,
    # warmup_steps=20,
    learning_rate=1e-4,
    weight_decay=0.01,
    logging_strategy="steps",
    logging_steps=1,
    logging_dir="./logs",
    save_strategy="epoch",
    # save_strategy="steps",
    # save_steps=10,
    save_total_limit=20,
    optim="adamw_hf", # for 8-bit, keep this, else adamw_hf
    # optim = "adamw_torch", # adamw_torch
    bf16=True, # underlying precision for 8bit
    output_dir=f"./{model_name}-256M-train-1a1r_3epoch_sft_action",
    report_to=None,
    remove_unused_columns=False,
    gradient_checkpointing=True,
    lr_scheduler_type="constant",
    eval_strategy='epoch',
    do_eval=True,

    load_best_model_at_end=True,
    metric_for_best_model='loss',
    greater_is_better=False,
)

# 建立 Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset_train,  # 設定訓練集
    eval_dataset=dataset_val,  # 設定驗證集
    data_collator=collate_fn,  # 讓 `Trainer` 正確批次處理 `image` 和 `text`
)

# 開始訓練
if __name__ == '__main__':
    trainer.train()