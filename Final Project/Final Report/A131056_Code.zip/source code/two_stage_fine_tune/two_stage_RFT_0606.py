# rloo_train_3phase.py
import os
import json
from tqdm import tqdm
import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer, AutoProcessor, Idefics3ForConditionalGeneration, CLIPModel, CLIPProcessor, CLIPTokenizerFast
import torch.nn.functional as F
from PIL import Image
import re

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
print(os.environ["CUDA_VISIBLE_DEVICES"]) 

# ---------------------------
# Dataset
# ---------------------------
class RLOODataset(Dataset):
    def __init__(self, path):
        with open(path, 'r') as f:
            self.data = json.load(f)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

# ---------------------------
# Utility functions for reward
# ---------------------------
def get_clip_similarity(image_pil, text, model, processor, tokenizer):
    text_inputs = tokenizer(text, padding='max_length', truncation=True, max_length=77, return_tensors="pt")
    text_input_ids = text_inputs["input_ids"].to(model.device)
    text_mask = text_inputs["attention_mask"].to(model.device)

    image_inputs = processor(images=image_pil, return_tensors="pt")["pixel_values"].to(model.device)

    with torch.no_grad():
        image_features = model.get_image_features(pixel_values=image_inputs)
        text_features = model.get_text_features(input_ids=text_input_ids, attention_mask=text_mask)
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
        similarity = (image_features * text_features).sum(dim=-1) * model.logit_scale.exp()
        prob = torch.sigmoid(similarity)
    return similarity.item(), prob.item()

# ---------------------------
# Reward Function Factory (online)
# ---------------------------
def reward_fn_factory(clip_model, clip_processor, clip_tokenizer):
    def reward_fn(samples, image_pil):
        rewards = []
        for s in samples:
            reason = s["response"].split("User:\n\n\n\n\nAssistant: ")[-1]
            _, prob = get_clip_similarity(image_pil, reason, clip_model, clip_processor, clip_tokenizer)
            rewards.append(prob)
        return rewards
    return reward_fn

# ---------------------------
# Logprob extraction
# ---------------------------
def extract_logprobs(logits, labels):
    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = labels[..., 1:].contiguous()
    log_probs = F.log_softmax(shift_logits, dim=-1)
    chosen_log_probs = torch.gather(log_probs, 2, shift_labels.unsqueeze(-1)).squeeze(-1)
    log_prob_sum = (chosen_log_probs * (shift_labels != -100)).sum(dim=1)
    return log_prob_sum

# ---------------------------
# Generate candidates
# ---------------------------
def generate_completions(processor, model, image, num_return_sequences=8):
    # system_message = """You are a Vision Language Model specialized in interpreting visual data from road scene images. Your task is to analyze the provided image and determine the appropriate driving action(s) along with the reason(s)."""
    # question = "What is the driver should take care about?"
    # question = "What is the object that effect the driver's behavior?"

    messages = [
        # {"role": "system", "content": [{"type": "text", "text": system_message}]},
        {"role": "user", "content": [
            # {"type": "text", "text": "Answer briefly."},
            {"type": "image"},
            # {"type": "text", "text": question}
        ]}
    ]

    prompt = processor.apply_chat_template(messages, add_generation_prompt=True)
    inputs = processor(text=prompt, images=image, return_tensors="pt").to(model.device)

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            do_sample=True,
            top_p=0.95,
            top_k=50,
            temperature=1.5,
            max_new_tokens=32,
            num_return_sequences=num_return_sequences,
            return_dict_in_generate=True
        )
        return processor.batch_decode(outputs.sequences, skip_special_tokens=True), prompt

# ---------------------------
# RLOO Step
# ---------------------------
def rloo_step(model, tokenizer, processor, reward_fn, image_tensor, full_entry, image_pil, optimizer):
    model.train()

    # step 1: generate completions
    completions, _ = generate_completions(processor, model, image_pil)

    # step 2: compute rewards
    samples = [{"response": c, **full_entry} for c in completions]
    rewards = reward_fn(samples, image_pil)

    # step 3: compute log probs for each completion
    logprobs = []
    for c in completions:
        inputs = tokenizer(c, return_tensors="pt", padding=True, truncation=True).to(model.device)
        outputs = model(**inputs)
        logp = extract_logprobs(outputs.logits, inputs["input_ids"])
        logprobs.append(logp)

    logprobs = torch.stack(logprobs).squeeze()
    rewards = torch.tensor(rewards).to(model.device)
    K = len(rewards)

    # step 4: leave-one-out baselines
    baselines = torch.tensor([(rewards.sum() - rewards[i]) / (K - 1) for i in range(K)]).to(model.device)
    advantages = rewards - baselines

    # step 5: compute loss and update
    loss = -advantages * logprobs
    loss = loss.mean()

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # return loss.item(), completions, rewards.tolist()
    
    best_idx = torch.argmax(rewards).item()
    best_completion = completions[best_idx]

    return loss.item(), completions, rewards.tolist(), best_completion

# ---------------------------
# Main training loop
# ---------------------------
def train_all_phases():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_id = "HuggingFaceTB/SmolVLM-256M-Instruct"
    model_path = r"D:\PH5\PH5\RL\checkpoints_rloo_only_0606\stage1_model_reason_epoch1"

    model = Idefics3ForConditionalGeneration.from_pretrained(
        model_path,
        # model_id,
        torch_dtype=torch.bfloat16,
        _attn_implementation="flash_attention_2" if device == "cuda" else "eager",
    ).to(device)

    tokenizer = AutoTokenizer.from_pretrained(model_id)
    processor = AutoProcessor.from_pretrained(model_id, use_fast=True)

    clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
    clip_ckpt = torch.load(r"D:\PH5\PH5\RL\clip_finetuned_models_reason\best_clip_judgement_model_reason.pth", map_location=device, weights_only=True)
    clip_model.load_state_dict(clip_ckpt)
    clip_model = clip_model.to(device)  
    clip_model.eval()

    clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
    clip_tokenizer = CLIPTokenizerFast.from_pretrained("openai/clip-vit-base-patch32")

    data_path = r"D:\PH5\PH5\RL\bdd_train_1act&1rsn_1407.json"
    save_dir = "checkpoints_rloo_only_0607"
    os.makedirs(save_dir, exist_ok=True)
    dataset = RLOODataset(data_path)

    reward_fn = reward_fn_factory(clip_model, clip_processor, clip_tokenizer)
    log_path = os.path.join(save_dir, f"stage1_log_caption.json")

    img_root = r"D:\PH5\lastframe\img"
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-6)
    num_epochs = 1
    for epoch in range(num_epochs):
        logs = []
        epoch_ckpt = os.path.join(save_dir, f"stage1_model_reason_epoch{epoch+5}")
        os.makedirs(epoch_ckpt, exist_ok=True)
        log_path = os.path.join(epoch_ckpt, f"logs_epoch_{epoch+1}.jsonl")
        for step, entry in enumerate(tqdm(dataset, desc=f"stage1 epoch {epoch+5}")):
            image_path = os.path.join(img_root, entry["file_name"])
            if not os.path.exists(image_path):
                continue
            image_pil = Image.open(image_path).convert("RGB")  # 強制轉為 RGB 模式
            image_tensor = processor(images=image_pil, return_tensors="pt")['pixel_values'].squeeze(0).to(device)
            loss, completions, rewards, best_completion = rloo_step(model, tokenizer, processor, reward_fn, image_tensor, entry, image_pil, optimizer)

            logs.append({
                "step": step,
                "loss": loss,
                "rewards": rewards,
                "completions": [c.split("User:\n\n\n\n\nAssistant: ")[-1].strip() for c in completions],
                "best_completion": best_completion.split("User:\n\n\n\n\nAssistant: ")[-1].strip()
            })

            # print(f"loss: {loss},rewards: {rewards}")

            if (step + 1) % 100 == 0:
                model.save_pretrained(epoch_ckpt)
                tokenizer.save_pretrained(epoch_ckpt)
                with open(log_path, 'a') as f:
                    for l in logs:
                        f.write(json.dumps(l) + "\n")
                logs.clear()

    # save final
    model.save_pretrained(epoch_ckpt)
    tokenizer.save_pretrained(epoch_ckpt)
    with open(log_path, 'a') as f:
        for l in logs:
            f.write(json.dumps(l) + "\n")

if __name__ == "__main__":
    train_all_phases()
