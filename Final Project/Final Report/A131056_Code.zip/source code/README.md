以下README.md是針對Label-Efficient Fine-Tuning of VLMs for Interpretable Autonomous Driving via RLOO Algorithm的說明。

壹、研究主架構包含兩個階段的訓練流程(詳細內容包含在two_stage_fine_tune的資料夾中)：

    1. Reinforcement Fine-Tuning (RFT, RLOO)：使用 CLIP reward 進行強化學習以提升模型在解釋與判斷上的表現。
    2. Supervised Fine-Tuning (SFT)：先產生 caption，再根據 caption + image 預測動作。

-----------------------------------------------------------------------------------

檔案說明

    檔案名稱：two_stage_RFT_0606.py
    功能    ：執行第一階段的強化學習
    檔案名稱：two_stage_sft_action.py
    功能    ：執行第二階段的監督式訓練

-----------------------------------------------------------------------------------

環境需求

* Python 3.10+
* PyTorch 2.0+
* Transformers (HuggingFace)
* Datasets (HuggingFace)
* PIL (Pillow)
* tqdm

安裝建議：

pip install torch torchvision torchaudio
pip install transformers datasets pillow tqdm

----------------------------------------------------------------------------------

資料準備

    RFT 階段需準備：
    JSON 格式的訓練資料（如：'bdd_train_1act&1rsn_1407.json'），每筆包含圖片'file_name'和 GT text(此階段用不到)。
    對應的圖片資料夾
    Fine-tuned CLIP model 檔案：best_clip_judgement_model_reason.pth，用來計算 reward。

    SFT 階段需準備：已處理好的 HuggingFace Dataset 格式資料集：
    本專案使用訓練集：bdd_train_1act&1rsn_1407
    本專案使用驗證集：bdd_train_1act&1rsn_200
    每筆包含圖片'file_name'和 GT text
    圖片資料夾 (圖片路徑需與 dataset 中 "image" 欄位對應)

-----------------------------------------------------------------------------------

執行方式

    1. 執行 RFT 階段：python two_stage_RFT_0606.py
       預設只訓練一個 epoch，可修改 num_epochs 改變訓練次數
       模型與日誌會儲存在 checkpoints_rloo_only_0606/


    2. 執行 SFT 階段：python two_stage_sft_action.py
       會自動載入模型與資料集
       模型輸出路徑：./SmolVLM-256M-train-1a1r_3epoch_sft_action/

-----------------------------------------------------------------------------------

訓練邏輯簡介

    Reinforcement Fine-Tuning（RFT）
    1. 使用模型從圖片產生多個描述回應。
    2. 使用 fine-tuned CLIP 模型計算各回應的語意分數。
    3. 應用 RLOO（Reward-Leave-One-Out）策略計算 loss 並更新模型。

    Supervised Fine-Tuning（SFT）
    1. 使用模型自動產生圖像描述（caption）。
    2. 將 caption、圖片與 prompt 組合成新對話，用於訓練模型預測動作，作為最終輸出結果。

----------------------------------------------------------------------------------

輸出結果

    1. RFT
    每 100 step 儲存一次模型與對應 .jsonl 記錄檔案
    completion, best_completion 與 rewards 會記錄於訓練過程中

    2. SFT
    日誌紀錄於 ./logs/
    訓練後模型與 tokenizer 儲存在指定 output 資料夾。

---------------------------------------------------------------------------------

NOTE：
    1. 如果有多張顯卡，可以開啟 DDP 功能，加快訓練

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

貳、ClIP 模型的fine-tuning (詳細內容在FT_clip_image_reason_0602.ipynb)

為了有效計算 Reinforcement Fine-Tuning（RFT, RLOO）中所需的 CLIP reward，我們需先對 CLIP 模型進行微調，使其更適應自駕車場景的image-text pairing的任務。

在先前的 toy task 中，由於尚未對模型進行微調，導致其在後續訓練中的表現明顯不足。例如，當我們計算預訓練 CLIP 模型對 ground truth中image-text pair 的match percent與average similarity probabilities時，可以發現模型無法準確辨識圖片與對應的行為描述（action）及其原因（reason）之間的語意關聯，進而影響 reward 與後續training的效果。

以下是微調的步驟：
    1. 建立圖片與文字說明配對資料集，包含positive pairs（語意對應）與negative pairs（語意不符）。
    2. 使用 OpenAI CLIP (ViT-B/32) 模型進行微調，判斷圖片與文字是否語意一致（binary classification任務，且threshold 設定為0.5）。

---------------------------------------------------------------------------------
檔案說明
檔案名稱：FT_clip_image_reason_0602.ipynb
功能    ：微調 CLIP 模型以預測圖片與文字說明是否對應
    
---------------------------------------------------------------------------------
環境需求
* Python 
* PyTorch 
* torchvision
* transformers
* scikit-learn
* torchmetrics
* Pillow
* seaborn
* tqdm
        
---------------------------------------------------------------------------------
安裝建議：
pip install torch torchvision transformers scikit-learn torchmetrics tqdm seaborn Pillow
建議使用具備 CUDA 的 GPU 執行訓練。
        
---------------------------------------------------------------------------------
資料準備：
    1. 圖片資料夾：內含 .jpg 或 .png 格式圖片，檔名需與 JSON 檔案中 "file_name" 欄位對應。
       此部分在程式碼的資料路經為/content/drive/MyDrive/RL_final_project/bdd_for_clip/data
    2. 說明檔 JSON (reason)：每筆資料包含"file_name"與對應的文字(reason)說明與標註。
       此部分在程式碼中是使用bdd_all_1a1r.json，且資料路徑為/content/drive/MyDrive/RL_final_project/bdd_all_1a1r.json

fine tuning 邏輯簡介
	•	使用來自 BDD 資料集的image-text paits資料 (可嘗試pre-processing，將資料統一成特定格式)
	•	建立positive pairs（image-text語意匹配）與negative pairs（隨機打亂的不匹配樣本）
	•	使用Binary Cross-Entropy Loss 微調 CLIP 模型
	•	實作Stratified Split (train: 1400/ valisdation: 200/ test: 400)、Data Augmentation, Early Stopping, ReduceLROnPlateau等技術
	•	評估指標包括：Accuracy、F1 score、AUROC、Recall，並繪製 ROC curve 與confusion matrix

---------------------------------------------------------------------------------
NOTE：
    1. 模型使用 OpenAI CLIP（ViT-B/32）作為 backbone，詳見：https://huggingface.co/openai/clip-vit-base-patch32
    2. 使用之圖片與說明資料來自 Berkeley DeepDrive（BDD）資料集：https://bair.berkeley.edu/blog/2018/05/30/bdd/
    3. 為了比較pretrained 與fine-tuned後的模型表現，使用evaluation_pretrain_clip.ipynb計算pretrained model 的prediction accuracy以及針對Ground Truth 的match percent與average similarity probability
